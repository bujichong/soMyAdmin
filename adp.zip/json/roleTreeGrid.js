[{
  "id":1,
    "pid" : 0,
  "name":"根模块",
  "all" : false,
  "add":false,
  "edit":false,
  "del":false,
  "look":false
},
{
  "id":2,
    "pid" : 1,
  "name":"系统管理",
  "all" : false,
  "add":false,
  "edit":false,
  "del":false,
  "look":false
},
{
  "id":3,
    "pid" : 2,
  "name":"用户管理",
  "all" : false,
  "add":false,
  "edit":false,
  "del":false,
  "look":false
},{
  "id":31,
    "pid" : 2,
  "name":"模块管理",
  "all" : false,
  "add":false,
  "edit":false,
  "del":false,
  "look":false
},{
  "id":4,
    "pid" : 1,
  "name":"功能管理",
  "all" : false,
  "add":false,
  "edit":false,
  "del":false,
  "look":false
}]