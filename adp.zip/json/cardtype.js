[{"text":"身份证","value":"1","selected":true},{"text":"军官证","value":"2"},{"text":"其他","value":"3"}]
