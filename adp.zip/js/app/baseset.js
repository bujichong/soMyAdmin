define(['plus/editor'] ,function(editor){
    var back = {
        init : function () {
            editor();
        }
    }
    return back;
});
